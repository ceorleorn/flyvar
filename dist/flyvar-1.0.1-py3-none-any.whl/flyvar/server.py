class Server():
    pass
