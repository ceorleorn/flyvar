## 安装

#### 从Pip下载

`pip install flyvar`

## 服务端

