import os
import sys

import client
import server
a = 1