# 前言
#### 你可能厌倦了PyMsql的枯燥，那就看看Flyvar吧.他不臃肿，简易.基于Python3构建
# 安装
#### Flyvar的大小可能出乎你的，他的源码只有12K左右。并且没有依赖超过三个需要安装的库.
#### 在Pip安装
`pip install flyvar`
# 服务端
#### Flyvar与Mysql一样，需要服务端和客户端。需要客户端通过连接服务器来操作数据，当然也可以把服务端放在与客户端在一个主机上！
## Server类
```python
import flyvar
db = flyvar.Server(host='127.0.0.1',port=18012)
```
### Server类是整个服务端的对象，他可以帮助服务端运行和处理事务.可以在赋值时指定运行的端口
## Server.run()
```python
import flyvar
db = flyvar.Server()
db.Run()